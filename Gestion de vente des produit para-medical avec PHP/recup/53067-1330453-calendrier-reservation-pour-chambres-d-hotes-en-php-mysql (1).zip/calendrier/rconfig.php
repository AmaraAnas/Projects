<?php
// configutation des chambres
$nchambres = 2;
$chambres_names = array("Atacama","Punakaiki","Malleo");
$chambres_initiales = array("At","Pu","Ma");
$chambres_colors = array ( '#FF9900' ,'#666633',"#5588B9" );
$chambres_npers = array ( 2 , 2 , 4 );
// synchro avec google calendar ( voir protected/gdata.php )
$synchro_gdata = false;

?>