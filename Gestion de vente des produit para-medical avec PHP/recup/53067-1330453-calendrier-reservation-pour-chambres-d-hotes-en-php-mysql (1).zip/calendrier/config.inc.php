<?php
$hote = "localhost";
$user = "root";
$password = "machako";
$base = "jourdets";
?>